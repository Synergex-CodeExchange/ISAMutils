SUBMISSION AUTHOR:      Synergy/DE Developer Support
                        mail to: support@synergex.com
                        Synergex
                        2330 Gold Meadow Way
                        Gold River, CA 95670
                        Phone: 916-635-7300
                        http://www.synergex.com

SUBMISSION NAME:        ISAMutils
SUBMISSION FILENAME:    ISAMutils.zip

PLATFORM:               Windows

SYNERGY VERSION:        Synergy v9.1.5 or higher

MODIFICATION HISTORY:   May 20, 2011 -  Initial posting onto CodeExchange

DESCRIPTION:            ISAM Utils is a GUI wrapper to the ISAM utilities - ISUTIL, IPAR, and FCONVERT.
			ISAM Utils provides a convenient way to run these utilities with all their options
			available to the user in a familiar Windows interface application.


REQUIREMENTS:		Microsoft Visual Studio 2010 Professional or higher
                    	Synergy/DE 9.5.1a or higher
                    	Synergy Language Integration for Visual Studio 9.5.1a or higher

ADDITIONAL NOTES:	The submission also has the project built into an executable (ISAMUtils.exe) 
			so that the utility may be utilized without building the source.